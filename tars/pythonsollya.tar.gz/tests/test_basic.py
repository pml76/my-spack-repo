import sollya


sollya.printfloat(1.1)
sollya.printdouble(1.3)
