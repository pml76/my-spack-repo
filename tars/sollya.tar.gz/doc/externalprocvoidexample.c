#include <stdio.h>

int foo() {

  printf("Hello from the external world.\n");

  return 1;
}
