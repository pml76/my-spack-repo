<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; display=binary!;<br>
&nbsp;&nbsp;&nbsp;&gt; prec=12!;<br>
&nbsp;&nbsp;&nbsp;&gt; a=pi;<br>
&nbsp;&nbsp;&nbsp;&gt; a;<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 12 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;1.10010010001_2 * 2^(1)<br>
&nbsp;&nbsp;&nbsp;&gt; prec=30!;<br>
&nbsp;&nbsp;&nbsp;&gt; a;<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 30 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;1.10010010000111111011010101001_2 * 2^(1)<br>
</div>
