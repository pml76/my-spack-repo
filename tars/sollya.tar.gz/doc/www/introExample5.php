<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; prec;<br>
&nbsp;&nbsp;&nbsp;165<br>
&nbsp;&nbsp;&nbsp;&gt; prec=200;<br>
&nbsp;&nbsp;&nbsp;The precision has been set to 200 bits.<br>
&nbsp;&nbsp;&nbsp;&gt; prec;<br>
&nbsp;&nbsp;&nbsp;200<br>
&nbsp;&nbsp;&nbsp;&gt; f(-2);<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 200 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;0.4546487134128408476980099329558724213511274857239451341894865<br>
</div>
