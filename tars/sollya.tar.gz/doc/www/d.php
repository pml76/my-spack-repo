<a name="d"></a> 
<div class="divName"> 
<h2 class="name">Name:</h2> <?php linkTo("command","d","D");?> 
<span class="smallDescription">short form for <?php linkTo("command","double","double");?> 
</span> 
</div> 
<div class="divExamples"> 
</div> 
<div class="divSeeAlso"> 
<span class="category">See also: </span><?php linkTo("command","double","double");?> 
</div> 
