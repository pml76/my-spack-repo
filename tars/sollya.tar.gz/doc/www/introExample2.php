<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; x = 3;<br>
&nbsp;&nbsp;&nbsp;Warning: the identifier "x" is already bound to the free variable, to a library function, library constant or to an external procedure.<br>
&nbsp;&nbsp;&nbsp;The command will have no effect.<br>
&nbsp;&nbsp;&nbsp;Warning: the last assignment will have no effect.<br>
</div>
