<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; prec=30;<br>
&nbsp;&nbsp;&nbsp;The precision has been set to 30 bits.<br>
&nbsp;&nbsp;&nbsp;&gt; prec=30!;<br>
&nbsp;&nbsp;&nbsp;&gt;  <br>
</div>
