<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; [1;2] + [3;4];<br>
&nbsp;&nbsp;&nbsp;[4;6]<br>
&nbsp;&nbsp;&nbsp;&gt; [1;2] * [3;4];<br>
&nbsp;&nbsp;&nbsp;[3;8]<br>
&nbsp;&nbsp;&nbsp;&gt; sqrt([9;25]);<br>
&nbsp;&nbsp;&nbsp;[3;5]<br>
&nbsp;&nbsp;&nbsp;&gt; exp(sin([10;100]));<br>
&nbsp;&nbsp;&nbsp;[0.36787942;2.718282]<br>
</div>
