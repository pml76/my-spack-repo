<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; printdouble(a);<br>
&nbsp;&nbsp;&nbsp;0x4031400000000000<br>
&nbsp;&nbsp;&nbsp;&gt; printsingle(a);<br>
&nbsp;&nbsp;&nbsp;0x418a0000<br>
</div>
