<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; rename(x,y);<br>
&nbsp;&nbsp;&nbsp;Information: the free variable has been renamed from "x" to "y".<br>
&nbsp;&nbsp;&nbsp;&gt; g;<br>
&nbsp;&nbsp;&nbsp;cos(y) - 1<br>
&nbsp;&nbsp;&nbsp;&gt; x=3;<br>
&nbsp;&nbsp;&nbsp;&gt; x;<br>
&nbsp;&nbsp;&nbsp;3<br>
</div>
