<a name="dd"></a> 
<div class="divName"> 
<h2 class="name">Name:</h2> <?php linkTo("command","dd","DD");?> 
<span class="smallDescription">short form for <?php linkTo("command","doubledouble","doubledouble");?> 
</span> 
</div> 
<div class="divExamples"> 
</div> 
<div class="divSeeAlso"> 
<span class="category">See also: </span><?php linkTo("command","doubledouble","doubledouble");?> 
</div> 
