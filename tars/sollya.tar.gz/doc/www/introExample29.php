<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; L = [|true, false, 1,...,4, "Hello", exp(x)|];<br>
&nbsp;&nbsp;&nbsp;&gt; for i in L do i;<br>
&nbsp;&nbsp;&nbsp;true<br>
&nbsp;&nbsp;&nbsp;false<br>
&nbsp;&nbsp;&nbsp;1<br>
&nbsp;&nbsp;&nbsp;2<br>
&nbsp;&nbsp;&nbsp;3<br>
&nbsp;&nbsp;&nbsp;4<br>
&nbsp;&nbsp;&nbsp;Hello<br>
&nbsp;&nbsp;&nbsp;exp(x)<br>
</div>
