<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; f(-2);<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 165 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;0.45464871341284084769800993295587242135112748572394<br>
&nbsp;&nbsp;&nbsp;&gt; evaluate(f,-2);<br>
&nbsp;&nbsp;&nbsp;0.45464871341284084769800993295587242135112748572394<br>
</div>
