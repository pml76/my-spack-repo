<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; [|1,...,5|];<br>
&nbsp;&nbsp;&nbsp;[|1, 2, 3, 4, 5|]<br>
&nbsp;&nbsp;&nbsp;&gt; [|-5,...,5|];<br>
&nbsp;&nbsp;&nbsp;[|-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5|]<br>
&nbsp;&nbsp;&nbsp;&gt; [|3,...,1|];<br>
&nbsp;&nbsp;&nbsp;Warning: at least one of the given expressions or a subexpression is not correctly typed<br>
&nbsp;&nbsp;&nbsp;or its evaluation has failed because of some error on a side-effect.<br>
&nbsp;&nbsp;&nbsp;error<br>
&nbsp;&nbsp;&nbsp;&gt; [|true,...,false|];<br>
&nbsp;&nbsp;&nbsp;Warning: at least one of the given expressions or a subexpression is not correctly typed<br>
&nbsp;&nbsp;&nbsp;or its evaluation has failed because of some error on a side-effect.<br>
&nbsp;&nbsp;&nbsp;error<br>
</div>
