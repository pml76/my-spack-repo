<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; midpointmode = off;<br>
&nbsp;&nbsp;&nbsp;Midpoint mode has been deactivated.<br>
&nbsp;&nbsp;&nbsp;&gt; [17;17];<br>
&nbsp;&nbsp;&nbsp;[17;17]<br>
&nbsp;&nbsp;&nbsp;&gt; [exp(pi);exp(pi)];<br>
&nbsp;&nbsp;&nbsp;Warning: at least one of the given expressions is not a constant but requires evaluation.<br>
&nbsp;&nbsp;&nbsp;Evaluation is guaranteed to ensure the inclusion property. The approximate result is at least 165 bit accurate.<br>
&nbsp;&nbsp;&nbsp;[23.1406926327792690057290863679485473802661062426;23.140692632779269005729086367948547380266106242601]<br>
&nbsp;&nbsp;&nbsp;&gt; midpointmode = on;<br>
&nbsp;&nbsp;&nbsp;Midpoint mode has been activated.<br>
&nbsp;&nbsp;&nbsp;&gt; [17;17];<br>
&nbsp;&nbsp;&nbsp;[17]<br>
&nbsp;&nbsp;&nbsp;&gt; [exp(pi);exp(pi)];<br>
&nbsp;&nbsp;&nbsp;Warning: at least one of the given expressions is not a constant but requires evaluation.<br>
&nbsp;&nbsp;&nbsp;Evaluation is guaranteed to ensure the inclusion property. The approximate result is at least 165 bit accurate.<br>
&nbsp;&nbsp;&nbsp;0.231406926327792690057290863679485473802661062426~0/1~e2<br>
&nbsp;&nbsp;&nbsp;&gt; <br>
</div>
