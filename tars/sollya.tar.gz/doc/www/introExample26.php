<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; a = 3;<br>
&nbsp;&nbsp;&nbsp;&gt; b = 4;<br>
&nbsp;&nbsp;&nbsp;&gt; if (a == b) then print("Hello world");<br>
&nbsp;&nbsp;&nbsp;&gt; b = 3;<br>
&nbsp;&nbsp;&nbsp;&gt; if (a == b) then print("Hello world");<br>
&nbsp;&nbsp;&nbsp;Hello world<br>
&nbsp;&nbsp;&nbsp;&gt; if (a == b) then print("You are telling the truth") else print("Liar!");<br>
&nbsp;&nbsp;&nbsp;You are telling the truth<br>
</div>
