<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; [3];<br>
&nbsp;&nbsp;&nbsp;[3;3]<br>
&nbsp;&nbsp;&nbsp;&gt; [1/7];<br>
&nbsp;&nbsp;&nbsp;Warning: at least one of the given expressions is not a constant but requires evaluation.<br>
&nbsp;&nbsp;&nbsp;Evaluation is guaranteed to ensure the inclusion property. The approximate result is at least 24 bit accurate.<br>
&nbsp;&nbsp;&nbsp;[0.14285713;0.14285715]<br>
&nbsp;&nbsp;&nbsp;&gt; [exp(8)];<br>
&nbsp;&nbsp;&nbsp;Warning: at least one of the given expressions is not a constant but requires evaluation.<br>
&nbsp;&nbsp;&nbsp;Evaluation is guaranteed to ensure the inclusion property. The approximate result is at least 24 bit accurate.<br>
&nbsp;&nbsp;&nbsp;[2980.9578;2980.958]<br>
</div>
