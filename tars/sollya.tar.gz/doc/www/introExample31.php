<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; succ = proc(n) { return n + 1; };<br>
&nbsp;&nbsp;&nbsp;&gt; succ(5);<br>
&nbsp;&nbsp;&nbsp;6<br>
&nbsp;&nbsp;&nbsp;&gt; 3 + succ(0);<br>
&nbsp;&nbsp;&nbsp;4<br>
&nbsp;&nbsp;&nbsp;&gt; succ;<br>
&nbsp;&nbsp;&nbsp;proc(n)<br>
&nbsp;&nbsp;&nbsp;{<br>
&nbsp;&nbsp;&nbsp;nop;<br>
&nbsp;&nbsp;&nbsp;return (n) + (1);<br>
&nbsp;&nbsp;&nbsp;}<br>
</div>
