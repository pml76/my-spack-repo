<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; match 5 + 1 with <br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;1 + 5 : ("One plus five")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;6&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ("Six")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;5 + 1 : ("Five plus one");<br>
&nbsp;&nbsp;&nbsp;Five plus one<br>
&nbsp;&nbsp;&nbsp;&gt; <br>
&nbsp;&nbsp;&nbsp;&gt; match 6 with <br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;1 + 5 : ("One plus five")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;6&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ("Six")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;5 + 1 : ("Five plus one");<br>
&nbsp;&nbsp;&nbsp;Six<br>
&nbsp;&nbsp;&nbsp;&gt; &nbsp;&nbsp;<br>
&nbsp;&nbsp;&nbsp;&gt; match 1 + 5 with <br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;1 + 5 : ("One plus five")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;6&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ("Six")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;5 + 1 : ("Five plus one");<br>
&nbsp;&nbsp;&nbsp;One plus five<br>
&nbsp;&nbsp;&nbsp;&gt; <br>
&nbsp;&nbsp;&nbsp;&gt; match [1; 5 + 1] with<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;[1; 1 + 5] : ("Interval from one to one plus five")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;[1; 6]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ("Interval from one to six")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;[1; 5 + 1] : ("Interval from one to five plus one");<br>
&nbsp;&nbsp;&nbsp;Interval from one to one plus five<br>
&nbsp;&nbsp;&nbsp;&gt; <br>
&nbsp;&nbsp;&nbsp;&gt; match [1; 6] with<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;[1; 1 + 5] : ("Interval from one to one plus five")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;[1; 6]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ("Interval from one to six")<br>
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;[1; 5 + 1] : ("Interval from one to five plus one");<br>
&nbsp;&nbsp;&nbsp;Interval from one to one plus five<br>
&nbsp;&nbsp;&nbsp;&gt; <br>
</div>
