<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; midpointmode = on!;<br>
&nbsp;&nbsp;&nbsp;&gt; [1.725e4;1.75e4];<br>
&nbsp;&nbsp;&nbsp;0.17~2/5~e5<br>
&nbsp;&nbsp;&nbsp;&gt; 0.17~2/5~e5;<br>
&nbsp;&nbsp;&nbsp;0.17~2/5~e5<br>
&nbsp;&nbsp;&nbsp;&gt; midpointmode = off!;<br>
&nbsp;&nbsp;&nbsp;&gt; 0.17~2/5~e5;<br>
&nbsp;&nbsp;&nbsp;[17200;17500]<br>
</div>
