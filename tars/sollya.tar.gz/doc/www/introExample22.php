<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; L = [|1,2,3,4,5|];<br>
&nbsp;&nbsp;&nbsp;&gt; L;<br>
&nbsp;&nbsp;&nbsp;[|1, 2, 3, 4, 5|]<br>
&nbsp;&nbsp;&nbsp;&gt; L[3];<br>
&nbsp;&nbsp;&nbsp;4<br>
</div>
