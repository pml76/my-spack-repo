<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; log2(5)/log2(17) - log(5)/log(17);<br>
&nbsp;&nbsp;&nbsp;Warning: rounding may have happened.<br>
&nbsp;&nbsp;&nbsp;If there is rounding, the displayed value is *NOT* guaranteed to be a faithful rounding of the true result.<br>
&nbsp;&nbsp;&nbsp;0<br>
</div>
