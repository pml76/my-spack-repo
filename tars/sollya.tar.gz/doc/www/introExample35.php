<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; add = proc(m,n) { var res; res := m + n; return res; };<br>
&nbsp;&nbsp;&nbsp;&gt; add(5,6);<br>
&nbsp;&nbsp;&nbsp;11<br>
&nbsp;&nbsp;&nbsp;&gt; hey = proc() { print("Hello world."); };<br>
&nbsp;&nbsp;&nbsp;&gt; hey();<br>
&nbsp;&nbsp;&nbsp;Hello world.<br>
&nbsp;&nbsp;&nbsp;&gt; print(hey());<br>
&nbsp;&nbsp;&nbsp;Hello world.<br>
&nbsp;&nbsp;&nbsp;void<br>
&nbsp;&nbsp;&nbsp;&gt; hey;<br>
&nbsp;&nbsp;&nbsp;proc()<br>
&nbsp;&nbsp;&nbsp;{<br>
&nbsp;&nbsp;&nbsp;print("Hello world.");<br>
&nbsp;&nbsp;&nbsp;return void;<br>
&nbsp;&nbsp;&nbsp;}<br>
</div>
