<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; d=[1;3];<br>
&nbsp;&nbsp;&nbsp;&gt; inf(d);<br>
&nbsp;&nbsp;&nbsp;1<br>
&nbsp;&nbsp;&nbsp;&gt; mid(d);<br>
&nbsp;&nbsp;&nbsp;2<br>
&nbsp;&nbsp;&nbsp;&gt; sup(4);<br>
&nbsp;&nbsp;&nbsp;4<br>
</div>
