<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; L = [|1,2,true,3...|];<br>
&nbsp;&nbsp;&nbsp;&gt; L;<br>
&nbsp;&nbsp;&nbsp;[|1, 2, true, 3...|]<br>
&nbsp;&nbsp;&nbsp;&gt; L[2];<br>
&nbsp;&nbsp;&nbsp;true<br>
&nbsp;&nbsp;&nbsp;&gt; L[3];<br>
&nbsp;&nbsp;&nbsp;3<br>
&nbsp;&nbsp;&nbsp;&gt; L[4];<br>
&nbsp;&nbsp;&nbsp;4<br>
&nbsp;&nbsp;&nbsp;&gt; L[1200];<br>
&nbsp;&nbsp;&nbsp;1200<br>
&nbsp;&nbsp;&nbsp;&gt; L = [|1,...,5,true...|];<br>
&nbsp;&nbsp;&nbsp;&gt; L;<br>
&nbsp;&nbsp;&nbsp;[|1, 2, 3, 4, 5, true...|]<br>
&nbsp;&nbsp;&nbsp;&gt; L[1200];<br>
&nbsp;&nbsp;&nbsp;true<br>
</div>
