<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; f = sin(x)/x;<br>
&nbsp;&nbsp;&nbsp;&gt; g = cos(y)-1;<br>
&nbsp;&nbsp;&nbsp;Warning: the identifier "y" is neither assigned to, nor bound to a library function nor external procedure, nor equal to the current free variable.<br>
&nbsp;&nbsp;&nbsp;Will interpret "y" as "x".<br>
&nbsp;&nbsp;&nbsp;&gt; g;<br>
&nbsp;&nbsp;&nbsp;cos(x) - 1<br>
</div>
