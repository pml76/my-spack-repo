<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; prec=30!;<br>
&nbsp;&nbsp;&nbsp;&gt; a = 17.25;<br>
&nbsp;&nbsp;&nbsp;&gt; display=decimal;<br>
&nbsp;&nbsp;&nbsp;Display mode is decimal numbers.<br>
&nbsp;&nbsp;&nbsp;&gt; a;<br>
&nbsp;&nbsp;&nbsp;17.25<br>
&nbsp;&nbsp;&nbsp;&gt; display=binary;<br>
&nbsp;&nbsp;&nbsp;Display mode is binary numbers.<br>
&nbsp;&nbsp;&nbsp;&gt; a;<br>
&nbsp;&nbsp;&nbsp;1.000101_2 * 2^(4)<br>
&nbsp;&nbsp;&nbsp;&gt; display=powers;<br>
&nbsp;&nbsp;&nbsp;Display mode is dyadic numbers in integer-power-of-2 notation.<br>
&nbsp;&nbsp;&nbsp;&gt; a;<br>
&nbsp;&nbsp;&nbsp;69 * 2^(-2)<br>
&nbsp;&nbsp;&nbsp;&gt; display=dyadic;<br>
&nbsp;&nbsp;&nbsp;Display mode is dyadic numbers.<br>
&nbsp;&nbsp;&nbsp;&gt; a;<br>
&nbsp;&nbsp;&nbsp;69b-2<br>
&nbsp;&nbsp;&nbsp;&gt; display=hexadecimal;<br>
&nbsp;&nbsp;&nbsp;Display mode is hexadecimal numbers.<br>
&nbsp;&nbsp;&nbsp;&gt; a;<br>
&nbsp;&nbsp;&nbsp;0x1.14p4<br>
</div>
