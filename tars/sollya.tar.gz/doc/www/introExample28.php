<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; for i from 1 to 5 do print ("Hello world",i);<br>
&nbsp;&nbsp;&nbsp;Hello world 1<br>
&nbsp;&nbsp;&nbsp;Hello world 2<br>
&nbsp;&nbsp;&nbsp;Hello world 3<br>
&nbsp;&nbsp;&nbsp;Hello world 4<br>
&nbsp;&nbsp;&nbsp;Hello world 5<br>
&nbsp;&nbsp;&nbsp;&gt; for i from 2 to 1 by -0.5 do print("Hello world",i);<br>
&nbsp;&nbsp;&nbsp;Hello world 2<br>
&nbsp;&nbsp;&nbsp;Hello world 1.5<br>
&nbsp;&nbsp;&nbsp;Hello world 1<br>
</div>
