<a name="de"></a> 
<div class="divName"> 
<h2 class="name">Name:</h2> <?php linkTo("command","de","DE");?> 
<span class="smallDescription">short form for <?php linkTo("command","doubleextended","doubleextended");?> 
</span> 
</div> 
<div class="divExamples"> 
</div> 
<div class="divSeeAlso"> 
<span class="category">See also: </span><?php linkTo("command","doubleextended","doubleextended");?> 
</div> 
