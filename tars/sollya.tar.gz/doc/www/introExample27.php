<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; verbosity = 0!;<br>
&nbsp;&nbsp;&nbsp;&gt; prec = 30!;<br>
&nbsp;&nbsp;&nbsp;&gt; i = 5;<br>
&nbsp;&nbsp;&nbsp;&gt; while (expm1(i) > 0) do { expm1(i); i := i - 1; };<br>
&nbsp;&nbsp;&nbsp;147.4131591<br>
&nbsp;&nbsp;&nbsp;53.59815<br>
&nbsp;&nbsp;&nbsp;19.08553693<br>
&nbsp;&nbsp;&nbsp;6.3890561<br>
&nbsp;&nbsp;&nbsp;1.718281828<br>
&nbsp;&nbsp;&nbsp;&gt; print(i);<br>
&nbsp;&nbsp;&nbsp;0<br>
</div>
