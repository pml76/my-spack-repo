<a name="interpolate"></a> 
<div class="divName"> 
<h2 class="name">Name:</h2> <?php linkTo("command","interpolate","interpolate");?> 
<span class="smallDescription">computes an interpolation polynomial. 
</span> 
</div> 
<div class="divLibraryName"> 
<h2 class="libraryname">Library names:</h2> 
<span class="commandline type">sollya_obj_t sollya_lib_interpolate(sollya_obj_t, sollya_obj_t, ...)</span> 
<span class="commandline type">sollya_obj_t sollya_lib_v_interpolate(sollya_obj_t, sollya_obj_t, va_list)</span> 
</div> 
<div class="divUsage"> 
<h2 class="category">Usage: </h2> 
<span class="commandline"><?php linkTo("command","interpolate","interpolate");?>(<span class="arg">X</span>, <span class="arg">Y</span>) : (<span class="type">list</span>, <span class="type">list</span>) -&gt; <span class="type">function</span></span> 
<span class="commandline"><?php linkTo("command","interpolate","interpolate");?>(<span class="arg">X</span>, <span class="arg">Y</span>, <span class="arg">D</span>) : (<span class="type">list</span>, <span class="type">list</span>, <span class="type">constant</span>) -&gt; <span class="type">function</span></span> 
<span class="commandline"><?php linkTo("command","interpolate","interpolate");?>(<span class="arg">X</span>, <span class="arg">Y</span>, <span class="arg">D</span>, <span class="arg">I</span>) : (<span class="type">list</span>, <span class="type">list</span>, <span class="type">constant</span>, <span class="type">range</span>) -&gt; <span class="type">function</span></span> 
<span class="commandline"><?php linkTo("command","interpolate","interpolate");?>(<span class="arg">X</span>, <span class="arg">f</span>) : (<span class="type">list</span>, <span class="type">function</span>) -&gt; <span class="type">function</span></span> 
<span class="commandline"><?php linkTo("command","interpolate","interpolate");?>(<span class="arg">X</span>, <span class="arg">f</span>, <span class="arg">D</span>) : (<span class="type">list</span>, <span class="type">function</span>, <span class="type">constant</span>) -&gt; <span class="type">function</span></span> 
<span class="commandline"><?php linkTo("command","interpolate","interpolate");?>(<span class="arg">X</span>, <span class="arg">f</span>, <span class="arg">D</span>, <span class="arg">I</span>) : (<span class="type">list</span>, <span class="type">function</span>, <span class="type">constant</span>, <span class="type">range</span>) -&gt; <span class="type">function</span></span> 
 
</div> 
<div class="divParameters"> 
<h2 class="category">Parameters: </h2> 
<ul> 
<li><span class="arg">X</span> is a list of constants for the interpolation abscissas</li> 
<li><span class="arg">Y</span> is a list of constants for the interpolation ordinates</li> 
<li><span class="arg">f</span> is a function to be interpolated</li> 
<li><span class="arg">D</span> is a constant defining the maximum permissible error</li> 
<li><span class="arg">I</span> is an interval defining the domain to be considered for the error</li> 
</ul> 
</div> 
<div class="divDescription"> 
<h2 class="category">Description: </h2><ul> 
<li><?php linkTo("command","interpolate","interpolate");?> computes an interpolation polynomial p such that for 
all given abscissa points xi in the list <span class="arg">X</span> the 
interpolation condition is fullfilled with p(xi) = yi, 
where yi is the corresponding entry in the list of 
ordinates <span class="arg">Y</span>. All entries of the lists <span class="arg">X</span> and <span class="arg">Y</span> need to be 
constant expressions; the entries in the list of abscissas <span class="arg">X</span> need to 
be pairwise distinct. If no parameter <span class="arg">D</span> is given, the interpolation 
is exact, i.e. an interpolation polynomial (expression) is formed such 
that the interpolation condition is satisfied without error. 
</li><li><?php linkTo("command","interpolate","interpolate");?> accepts a function <span class="arg">f</span> instead of a list of ordinates. When 
called in this manner, <?php linkTo("command","interpolate","interpolate");?> computes a polynomial p such 
that for all given abscissa points xi in the list <span class="arg">X</span> the 
interpolation condition is fullfilled with p(xi) = f(xi). 
All entries in the list <span class="arg">X</span> still need to be constant expressions 
and they must be pairwise distinct. If no parameter <span class="arg">D</span> is given, 
the interpolation stays exact, even if this means forming constant 
expressions for the ordinates f(xi). 
</li><li>As exact interpolation is often not needed and in order to speed up 
computations, <?php linkTo("command","interpolate","interpolate");?> accepts an optional parameter <span class="arg">D</span>, a positive 
constant, that defines the maximum permissible error. In this case, 
instead of computing the exact interpolation polynomial p as 
it is defined above, <?php linkTo("command","interpolate","interpolate");?> computes and returns an approximate 
interpolation polynomial p~ that does not differ from 
p more than the amount <span class="arg">D</span> with supremum norm over the 
interval I that is given by the intervall of all abscissa 
points in <span class="arg">X</span>. 
Formally, let I be the interval hull of all abscissa points in 
<span class="arg">X</span>; typically, the lower bound of I is the minimum value 
amongst all <span class="arg">X</span>, the upper bound is the maximum value amongst all 
<span class="arg">X</span>. Let p be the unique polynomial such that p(xi) = yi 
for all xi in the list <span class="arg">X</span> and yi either the 
corresponding entry in the list <span class="arg">Y</span> or yi = f(xi). 
Then <?php linkTo("command","interpolate","interpolate");?> returns p~ such that 
||p~ - p ||^I &lt;= D. 
The support for <span class="arg">D</span> works for any list of distinct abscissa points <span class="arg">X</span> 
and for any list of ordinate points <span class="arg">Y</span> or function <span class="arg">f</span>. The algorithm 
is however optimized for the case when <span class="arg">X</span> is a list of floating-point 
(or rational) constants and a function <span class="arg">f</span>. When <span class="arg">f</span> is a polynomial 
of degree n and <span class="arg">X</span> contains at least n+1 abscissa points, 
<?php linkTo("command","interpolate","interpolate");?> may return <span class="arg">f</span> as-is, even though <span class="arg">D</span> has been provided; typically 
without performing any rounding on the coefficients of the polynomial <span class="arg">f</span>. 
</li><li>When a permissible-error-argument <span class="arg">D</span> is given to <?php linkTo("command","interpolate","interpolate");?>, the command 
additionnally supports an optional interval parameter <span class="arg">I</span>. If this 
parameter is specified, the interval I to consider the error 
between p~ and p on is not taken as the 
interval hull of the abscissa points <span class="arg">X</span> but assumed to be the 
interval I. This parameter is supported to both allow for 
interpolation over intervals where the first (or last) interpolation 
point does not lie on the lower (resp. upper) bound of the interval 
and to speed up computation: determining the minimum and maximum 
values in <span class="arg">X</span> may be expensive. 
</li><li><?php linkTo("command","interpolate","interpolate");?> is completely insensible to the tool's working precision 
<?php linkTo("command","prec","prec");?>. It adapts its own working precision entirely 
automatically. However the user should be aware that precision 
adaption comes at a price: if the interpolation problem requires high 
precision to be solved, the execution time of <?php linkTo("command","interpolate","interpolate");?> will be 
high. This can typically be observed when the list of abscissas <span class="arg">X</span> 
contains two values that are mathematically different but for which 
high precision is needed to distinguish them. 
</li><li>In case of error, e.g. when the abscissa points in <span class="arg">X</span> are not 
all distinct, when the function does not evaluate at one of the 
abscissa points or when the permissible error <span class="arg">D</span> or domain interval <span class="arg">I</span> 
are not acceptable, <?php linkTo("command","interpolate","interpolate");?> evaluates to <?php linkTo("command","error","error");?>. 
</ul> 
</div> 
<div class="divExamples"> 
<div class="divExample"> 
<h2 class="category">Example 1: </h2> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3 |], [| 3, 5, 9 |]);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("p = ", p, "\n");<br> 
&nbsp;&nbsp;&nbsp;p = 3 + _x_ * (-1 + _x_)<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 2: </h2> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |]);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("p = ", p, "\n");<br> 
&nbsp;&nbsp;&nbsp;p = 21 + _x_ * (-100 / 3 + _x_ * (15.5 + _x_ * -13 / 6))<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |], 2^-17);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("p = ", p, "\n");<br> 
&nbsp;&nbsp;&nbsp;p = 21 + _x_ * (-33.33333301544189453125 + _x_ * (15.5 + _x_ * (-2.16666662693023681640625)))<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |], 2^-17, [0; 2^42]);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("p = ", p, "\n");<br> 
&nbsp;&nbsp;&nbsp;p = 21 + _x_ * (-33.33333333333333333347789362299806725786766037345 + _x_ * (15.5 + _x_ * (-2.1666666666666666666666666666666666666666666591931)))<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 3: </h2> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |]);<br> 
&nbsp;&nbsp;&nbsp;&gt; q = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |], 2^-17);<br> 
&nbsp;&nbsp;&nbsp;&gt; delta = horner(p - q);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("delta = ", delta, "\n");<br> 
&nbsp;&nbsp;&nbsp;delta = _x_ * (-1 / 3145728 + _x_^2 * -1 / 25165824)<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(delta,[1;4]);<br> 
&nbsp;&nbsp;&nbsp;&gt; "Delta = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;Delta = 3.814697265625e-6 = 2^(-18)<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |]);<br> 
&nbsp;&nbsp;&nbsp;&gt; q = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |], 2^-2000);<br> 
&nbsp;&nbsp;&nbsp;&gt; delta = horner(p - q);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("delta = ", delta, "\n");<br> 
&nbsp;&nbsp;&nbsp;delta = _x_ * (1 / 2.7555136686582108581587996828264367616535624850129e603 + _x_^2 * 1 / 2.2044109349265686865270397462611494093228499880103e604)<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(delta,[1;4]);<br> 
&nbsp;&nbsp;&nbsp;&gt; "Delta = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;Delta = 4.3549049081086083377880977473894361479295518713527e-603 = 2^(-2001)<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 4: </h2> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |]);<br> 
&nbsp;&nbsp;&nbsp;&gt; q = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |], 2^-17, [0;2^10]);<br> 
&nbsp;&nbsp;&nbsp;&gt; delta = horner(p - q);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("delta = ", delta, "\n");<br> 
&nbsp;&nbsp;&nbsp;delta = _x_ * (1 / 1610612736 + _x_^2 * -1 / 1688849860263936)<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(delta,[0;2^10]);<br> 
&nbsp;&nbsp;&nbsp;&gt; "Delta = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;Delta = 2.4471294368728034316556666925301338011322095712879e-7 = 2^(-21.962406251802890453634347359869541271899536019231)<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |]);<br> 
&nbsp;&nbsp;&nbsp;&gt; q = interpolate([| 1, 2, 3, 4 |], [| 1, -1, 2, -3 |], 2^-2000, [0;2^10]);<br> 
&nbsp;&nbsp;&nbsp;&gt; delta = horner(p - q);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("delta = ", delta, "\n");<br> 
&nbsp;&nbsp;&nbsp;delta = _x_ * (-1 / 1.4108229983530039593773054376071356219666239923266e606 + _x_^2 * 1 / 1.47935513632099947970801742654433984193927471937785e612)<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(delta,[0;2^10]);<br> 
&nbsp;&nbsp;&nbsp;&gt; "Delta = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;Delta = 2.7936728011019194195581558596099001590721546862147e-604 = 2^(-2004.9624062518028904536343473598695412718995360192)<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 5: </h2> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], 17 + _x_ * (42 + _x_ * (23 + _x_ * 1664)));<br> 
&nbsp;&nbsp;&nbsp;&gt; write("p = ", p, "\n");<br> 
&nbsp;&nbsp;&nbsp;p = 17 + _x_ * (42 + _x_ * (23 + _x_ * 1664))<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 6: </h2> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], exp(_x_));<br> 
&nbsp;&nbsp;&nbsp;&gt; write("p = ", p, "\n");<br> 
&nbsp;&nbsp;&nbsp;p = -1 * (-2 * (-3 * ((exp(4) - exp(3) - (exp(3) - exp(2))) / 2 - (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) / 3 + (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) + exp(2) - exp(1)) + exp(1) + _x_ * (-1 * (-2 * ((exp(4) - exp(3) - (exp(3) - exp(2))) / 2 - (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) / 3 + -3 * ((exp(4) - exp(3) - (exp(3) - exp(2))) / 2 - (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) / 3 + (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) + -2 * (-3 * ((exp(4) - exp(3) - (exp(3) - exp(2))) / 2 - (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) / 3 + (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) + exp(2) - exp(1) + _x_ * (-1 * ((exp(4) - exp(3) - (exp(3) - exp(2))) / 2 - (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) / 3 + -2 * ((exp(4) - exp(3) - (exp(3) - exp(2))) / 2 - (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) / 3 + -3 * ((exp(4) - exp(3) - (exp(3) - exp(2))) / 2 - (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) / 3 + (exp(3) - exp(2) - (exp(2) - exp(1))) / 2 + _x_ * ((exp(4) - exp(3) - (exp(3) - exp(2))) / 2 - (exp(3) - exp(2) - (exp(2) - exp(1))) / 2) / 3))<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], exp(_x_), 2^-17);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("p = ", p, "\n");<br> 
&nbsp;&nbsp;&nbsp;p = -7.71721172332763671875 + _x_ * (17.914661407470703125 + _x_ * (-9.77757251262664794921875 + _x_ * 2.298404276371002197265625))<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], exp(_x_), 2^-17, [0; 2^42]);<br> 
&nbsp;&nbsp;&nbsp;&gt; write("p = ", p, "\n");<br> 
&nbsp;&nbsp;&nbsp;p = -7.71721172332763671875 + _x_ * (17.9146616149694119287522076078289501310791820287704 + _x_ * (-9.777572455021435040741686047095908782922898736377 + _x_ * 2.2984042886523568836092778582480142756017855238293))<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 7: </h2> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], exp(_x_));<br> 
&nbsp;&nbsp;&nbsp;&gt; q = interpolate([| 1, 2, 3, 4 |], exp(_x_), 2^-17);<br> 
&nbsp;&nbsp;&nbsp;&gt; delta = horner(p - q);<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(delta,[1;4]);<br> 
&nbsp;&nbsp;&nbsp;&gt; "Delta = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;Delta = 2.64087128985936026120286087840279073703861406872586e-6 = 2^(-18.5305545798246903139105523606201676108779913563466)<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], exp(_x_));<br> 
&nbsp;&nbsp;&nbsp;&gt; q = interpolate([| 1, 2, 3, 4 |], exp(_x_), 2^-2000);<br> 
&nbsp;&nbsp;&nbsp;&gt; delta = horner(p - q);<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(delta,[1;4]);<br> 
&nbsp;&nbsp;&nbsp;&gt; "Delta = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;Delta = 1.4590823977486192906712389246433732155807613636698e-603 = 2^(-2002.5775798592063632271660191460324647977792574035)<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 8: </h2> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], exp(_x_));<br> 
&nbsp;&nbsp;&nbsp;&gt; q = interpolate([| 1, 2, 3, 4 |], exp(_x_), 2^-17, [0;2^10]);<br> 
&nbsp;&nbsp;&nbsp;&gt; delta = horner(p - q);<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(delta,[0;2^10]);<br> 
&nbsp;&nbsp;&nbsp;&gt; "Delta = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;Delta = 4.75462940203480522770747218406076244573282695611e-7 = 2^(-21.0041637691158024834926102190382130962658000640866)<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate([| 1, 2, 3, 4 |], exp(_x_));<br> 
&nbsp;&nbsp;&nbsp;&gt; q = interpolate([| 1, 2, 3, 4 |], exp(_x_), 2^-2000, [0;2^10]);<br> 
&nbsp;&nbsp;&nbsp;&gt; delta = horner(p - q);<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(delta,[0;2^10]);<br> 
&nbsp;&nbsp;&nbsp;&gt; "Delta = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;Delta = 9.0435150205780172429401306949628326405643331478968e-604 = 2^(-2003.2676856856633076178139050354211927790570412987)<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 9: </h2> 
&nbsp;&nbsp;&nbsp;&gt; f = exp(_x_);<br> 
&nbsp;&nbsp;&nbsp;&gt; I = [-1/2;1/2];<br> 
&nbsp;&nbsp;&nbsp;&gt; n = 17;<br> 
&nbsp;&nbsp;&nbsp;&gt; X = [||]; for i from 0 to n do X = (~(1/2 * (inf(I) + sup(I)) + 1/2 * (sup(I) - inf(I)) * cos(pi * ((2 * i + 1)/(2 * (n + 1)))))) .: X; X = revert(X);<br> 
&nbsp;&nbsp;&nbsp;&gt; p = interpolate(X, f, 2^-110);<br> 
&nbsp;&nbsp;&nbsp;&gt; q = remez(f, n, I);<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(p-f,I);<br> 
&nbsp;&nbsp;&nbsp;&gt; "||p-f|| = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;||p-f|| = 4.682282321340942778487515892686081216293095411976e-27 = 2^(-87.464846636624845038438119985399853470805747522283)<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(q-f,I);<br> 
&nbsp;&nbsp;&nbsp;&gt; "||q-f|| = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;||q-f|| = 4.5615560104462964431174181483603567519672456911095e-27 = 2^(-87.502532530192383004694428978646385337892102159012)<br> 
&nbsp;&nbsp;&nbsp;&gt; Delta = dirtyinfnorm(horner(p-q),I);<br> 
&nbsp;&nbsp;&nbsp;&gt; "||p-q|| = ", Delta, " = 2^(", log2(Delta), ")";<br> 
&nbsp;&nbsp;&nbsp;||p-q|| = 1.20729158377808689215008324924110505247080203008044e-28 = 2^(-92.742212500498778529126446648943330421384492990147)<br> 
</div> 
<div class="divExample"> 
<h2 class="category">Example 10: </h2> 
&nbsp;&nbsp;&nbsp;&gt; interpolate([| 1, 1 + 2^-1000 |], 17 + 42 * x);<br> 
&nbsp;&nbsp;&nbsp;17 + x * 42<br> 
&nbsp;&nbsp;&nbsp;&gt; interpolate([| 1, 1 + 2^-10000 |], 17 + 42 * x);<br> 
&nbsp;&nbsp;&nbsp;17 + x * 42<br> 
&nbsp;&nbsp;&nbsp;&gt; interpolate([| 1, 1 |], 17 + 42 * x);<br> 
&nbsp;&nbsp;&nbsp;error<br> 
</div> 
</div> 
<div class="divSeeAlso"> 
<span class="category">See also: </span><?php linkTo("command","remez","remez");?>, <?php linkTo("command","dirtyinfnorm","dirtyinfnorm");?>, <?php linkTo("command","supnorm","supnorm");?>, <?php linkTo("command","prec","prec");?>, <?php linkTo("command","error","error");?> 
</div> 
