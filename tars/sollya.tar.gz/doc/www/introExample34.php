<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; 1/3 - 1/7;<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 165 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;0.19047619047619047619047619047619047619047619047619<br>
&nbsp;&nbsp;&nbsp;&gt; rationalmode = on;<br>
&nbsp;&nbsp;&nbsp;Rational mode has been activated.<br>
&nbsp;&nbsp;&nbsp;&gt; 1/3 - 1/7;<br>
&nbsp;&nbsp;&nbsp;4 / 21<br>
&nbsp;&nbsp;&nbsp;&gt; (2 + 1/7)^2 + (6/7)^2 + 2 * (2 + 1/7) * 6/7;<br>
&nbsp;&nbsp;&nbsp;9<br>
&nbsp;&nbsp;&nbsp;&gt; rationalmode = off;<br>
&nbsp;&nbsp;&nbsp;Rational mode has been deactivated.<br>
&nbsp;&nbsp;&nbsp;&gt; (2 + 1/7)^2 + (6/7)^2 + 2 * (2 + 1/7) * 6/7;<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 165 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;9<br>
&nbsp;&nbsp;&nbsp;&gt; rationalmode = on;<br>
&nbsp;&nbsp;&nbsp;Rational mode has been activated.<br>
&nbsp;&nbsp;&nbsp;&gt; asin(1)/pi;<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 165 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;0.5<br>
&nbsp;&nbsp;&nbsp;&gt; sin(1/6 * pi);<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 165 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;0.5<br>
&nbsp;&nbsp;&nbsp;&gt; exp(1/7 - 3/21) / 7;<br>
&nbsp;&nbsp;&nbsp;1 / 7<br>
&nbsp;&nbsp;&nbsp;&gt; rationalmode = off;<br>
&nbsp;&nbsp;&nbsp;Rational mode has been deactivated.<br>
&nbsp;&nbsp;&nbsp;&gt; exp(1/7 - 3/21) / 7;<br>
&nbsp;&nbsp;&nbsp;Warning: rounding has happened. The value displayed is a faithful rounding to 165 bits of the true result.<br>
&nbsp;&nbsp;&nbsp;0.142857142857142857142857142857142857142857142857145<br>
&nbsp;&nbsp;&nbsp;&gt; print(1/7 - 3/21);<br>
&nbsp;&nbsp;&nbsp;1 / 7 - 3 / 21<br>
&nbsp;&nbsp;&nbsp;&gt; rationalmode = on;<br>
&nbsp;&nbsp;&nbsp;Rational mode has been activated.<br>
&nbsp;&nbsp;&nbsp;&gt; print(1/7 - 3/21);<br>
&nbsp;&nbsp;&nbsp;0<br>
</div>
