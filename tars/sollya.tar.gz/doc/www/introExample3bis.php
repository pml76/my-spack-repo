<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; f == sin(_x_)/_x_;<br>
&nbsp;&nbsp;&nbsp;true<br>
</div>
