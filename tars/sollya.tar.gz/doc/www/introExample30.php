<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; for i from 1 to 5 do { if (i == 3) then i = 4 else i; };<br>
&nbsp;&nbsp;&nbsp;1<br>
&nbsp;&nbsp;&nbsp;2<br>
&nbsp;&nbsp;&nbsp;5<br>
&nbsp;&nbsp;&nbsp;&gt; i;<br>
&nbsp;&nbsp;&nbsp;6<br>
</div>
