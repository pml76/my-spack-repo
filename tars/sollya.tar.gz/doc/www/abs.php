<a name="abs"></a> 
<div class="divName"> 
<h2 class="name">Name:</h2> <?php linkTo("command","abs","abs");?> 
<span class="smallDescription">the absolute value. 
</span> 
</div> 
<div class="divLibraryName"> 
<h2 class="libraryname">Library names:</h2> 
<span class="commandline type">sollya_obj_t sollya_lib_abs(sollya_obj_t)</span> 
<span class="commandline type">sollya_obj_t sollya_lib_build_function_abs(sollya_obj_t)</span> 
<span class="commandline type">#define SOLLYA_ABS(x) sollya_lib_build_function_abs(x)</span> 
</div> 
<div class="divDescription"> 
<h2 class="category">Description: </h2><ul> 
<li><?php linkTo("command","abs","abs");?> is the absolute value function. <?php linkTo("command","abs","abs");?>(x)=x if x&gt;0 and -x otherwise. 
</ul> 
</div> 
<div class="divExamples"> 
</div> 
