<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; d=[1;2];<br>
&nbsp;&nbsp;&nbsp;&gt; d2=[1,1+1];<br>
&nbsp;&nbsp;&nbsp;&gt; d==d2;<br>
&nbsp;&nbsp;&nbsp;true<br>
&nbsp;&nbsp;&nbsp;&gt; prec=12!;<br>
&nbsp;&nbsp;&nbsp;&gt; 8095.1;<br>
&nbsp;&nbsp;&nbsp;Warning: Rounding occurred when converting the constant "8095.1" to floating-point with 12 bits.<br>
&nbsp;&nbsp;&nbsp;If safe computation is needed, try to increase the precision.<br>
&nbsp;&nbsp;&nbsp;8096<br>
&nbsp;&nbsp;&nbsp;&gt; [8095.1; 8096.1];<br>
&nbsp;&nbsp;&nbsp;Warning: Rounding occurred when converting the constant "8095.1" to floating-point with 12 bits.<br>
&nbsp;&nbsp;&nbsp;The inclusion property is nevertheless satisfied.<br>
&nbsp;&nbsp;&nbsp;Warning: Rounding occurred when converting the constant "8096.1" to floating-point with 12 bits.<br>
&nbsp;&nbsp;&nbsp;The inclusion property is nevertheless satisfied.<br>
&nbsp;&nbsp;&nbsp;[8094;8098]<br>
</div>
