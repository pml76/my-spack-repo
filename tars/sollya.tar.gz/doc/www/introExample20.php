<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; s1 = "Hello "; s2 = "World!";<br>
&nbsp;&nbsp;&nbsp;&gt; s = s1@s2;<br>
&nbsp;&nbsp;&nbsp;&gt; length(s);<br>
&nbsp;&nbsp;&nbsp;12<br>
&nbsp;&nbsp;&nbsp;&gt; s[0];<br>
&nbsp;&nbsp;&nbsp;H<br>
&nbsp;&nbsp;&nbsp;&gt; s[11];<br>
&nbsp;&nbsp;&nbsp;!<br>
</div>
