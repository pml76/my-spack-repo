<div class="divExample">
&nbsp;&nbsp;&nbsp;&gt; prec=12!;<br>
&nbsp;&nbsp;&nbsp;&gt; 4097.1;<br>
&nbsp;&nbsp;&nbsp;Warning: Rounding occurred when converting the constant "4097.1" to floating-point with 12 bits.<br>
&nbsp;&nbsp;&nbsp;If safe computation is needed, try to increase the precision.<br>
&nbsp;&nbsp;&nbsp;4098<br>
&nbsp;&nbsp;&nbsp;&gt; 4098.1;<br>
&nbsp;&nbsp;&nbsp;Warning: Rounding occurred when converting the constant "4098.1" to floating-point with 12 bits.<br>
&nbsp;&nbsp;&nbsp;If safe computation is needed, try to increase the precision.<br>
&nbsp;&nbsp;&nbsp;4098<br>
&nbsp;&nbsp;&nbsp;&gt; 4097.1+1;<br>
&nbsp;&nbsp;&nbsp;Warning: Rounding occurred when converting the constant "4097.1" to floating-point with 12 bits.<br>
&nbsp;&nbsp;&nbsp;If safe computation is needed, try to increase the precision.<br>
&nbsp;&nbsp;&nbsp;4099<br>
</div>
