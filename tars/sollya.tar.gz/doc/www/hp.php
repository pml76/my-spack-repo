<a name="hp"></a> 
<div class="divName"> 
<h2 class="name">Name:</h2> <?php linkTo("command","hp","HP");?> 
<span class="smallDescription">short form for <?php linkTo("command","halfprecision","halfprecision");?> 
</span> 
</div> 
<div class="divExamples"> 
</div> 
<div class="divSeeAlso"> 
<span class="category">See also: </span><?php linkTo("command","halfprecision","halfprecision");?> 
</div> 
